EXEC [dbo].[AddInventoryRecords]
		@ServerName = N'Administrator\SQLExpress',
		@Description = N'Express instance'
