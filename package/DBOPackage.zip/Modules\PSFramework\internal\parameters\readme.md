﻿# Parameters

The PSFramework delivers dedicated, extensible parameter classes, that act as input converters.
It is possible to add support for additional input types by mapping the properties of the respective type.

All such additional mappings that ship within the PSFramework itself are stored here and can be used for reference.