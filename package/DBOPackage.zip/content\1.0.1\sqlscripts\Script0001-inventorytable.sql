/* Create a database table for storing server information */
CREATE TABLE [dbo].[DatabaseInventory] (
	[ServerName] NVARCHAR(60) NOT NULL,
	[Description] NVARCHAR(60) NULL
	)
GO


